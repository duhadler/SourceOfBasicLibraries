﻿def f(x): one=mpf(1); return sqrt((one + 2*x)/(one + x))
print f(122.3)


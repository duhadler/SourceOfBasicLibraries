The full project is currently located at

I:\Extra\mpFormulaTDM\ExternalLibraries\Python33

Included here are only the projects, NOT the .h or .lib files


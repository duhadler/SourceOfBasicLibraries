The full project is currently in

I:\Extra\mpFormulaTDM\ExternalTools\ExcelFinancialFunctions-master

This project needs to be cleaned up.

It is currently compiled in Windows 7 (English) with VSExpress 2013


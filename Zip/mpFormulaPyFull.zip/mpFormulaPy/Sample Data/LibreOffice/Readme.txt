The file sheetFunction.py need to be copied into ..\LibreOffice4\share\Scripts\python

The file StarBasic.bas is copied into MyMacros:Standard:Module1


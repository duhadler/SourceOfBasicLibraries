﻿'
' Created by SharpDevelop.
' User: DH
' Date: 28/07/2013
' Time: 11:26
' 
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'
Public Partial Class AboutForm
	Public Sub New()
		' The Me.InitializeComponent call is required for Windows Forms designer support.
		Me.InitializeComponent()
		
		'
		' TODO : Add constructor code after InitializeComponents
		'
	End Sub
	
	Sub BtnCloseClick(sender As Object, e As EventArgs)
		Me.Close()
	End Sub
End Class

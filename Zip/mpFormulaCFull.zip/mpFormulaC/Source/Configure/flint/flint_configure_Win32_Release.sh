./configure --build=x86-MINGW32  --enable-static --disable-shared ABI=32  CFLAGS="-m32 -march=i686 -Wno-attributes" --with-gmp=/local/Win32  --with-mpfr=/local/Win32  --prefix=/local/Win32 

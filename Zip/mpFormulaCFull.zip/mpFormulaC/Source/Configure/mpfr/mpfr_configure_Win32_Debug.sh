./configure --build=i686-w64-mingw32 --host=i686-w64-mingw32  --enable-static --disable-shared   CFLAGS="-m32 -g -march=i686 -Wno-attributes" --with-gmp-include=/local/Win32_Debug/include --with-gmp-lib=/local/Win32_Debug/lib  --prefix=/local/Win32_Debug --exec-prefix=/local/Win32_Debug  



./configure --build=i686-w64-mingw32 --host=i686-w64-mingw32  --disable-static --enable-shared  --disable-thread-safe   CFLAGS="-m32 -march=i686 -Wno-attributes" --with-gmp-include=/local/Win32_DLL/include --with-gmp-lib=/local/Win32_DLL/lib  --prefix=/local/Win32_DLL --exec-prefix=/local/Win32_DLL 



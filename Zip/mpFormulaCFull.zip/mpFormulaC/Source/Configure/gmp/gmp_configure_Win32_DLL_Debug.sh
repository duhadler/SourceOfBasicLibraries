./configure --build=i686-w64-mingw32 --host=i686-w64-mingw32 --enable-fat  --disable-static --enable-shared ABI=32 CFLAGS="-m32 -g -march=i686 -Wno-attributes"  --prefix=/local/Win32_DLL_Debug --exec-prefix=/local/Win32_DLL_Debug 


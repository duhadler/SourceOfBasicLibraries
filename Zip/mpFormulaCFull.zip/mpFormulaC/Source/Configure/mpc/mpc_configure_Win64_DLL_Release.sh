./configure --build=i686-w64-mingw32 --host=x86_64-w64-mingw32  --disable-static --enable-shared  CFLAGS="-m64 -march=k8 -Wno-attributes" --with-gmp-include=/local/Win64_DLL/include --with-gmp-lib=/local/Win64_DLL/lib  --with-mpfr-include=/local/Win64_DLL/include --with-mpfr-lib=/local/Win64_DLL/lib  --prefix=/local/Win64_DLL --exec-prefix=/local/Win64_DLL  




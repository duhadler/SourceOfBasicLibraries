./configure --build=i686-w64-mingw32 --host=i686-w64-mingw32  --enable-static --disable-shared  CFLAGS="-m32 -march=i686 -Wno-attributes" --with-gmp-include=/local/Win32/include --with-gmp-lib=/local/Win32/lib  --with-mpfr-include=/local/Win32/include --with-mpfr-lib=/local/Win32/lib  --prefix=/local/Win32 --exec-prefix=/local/Win32  




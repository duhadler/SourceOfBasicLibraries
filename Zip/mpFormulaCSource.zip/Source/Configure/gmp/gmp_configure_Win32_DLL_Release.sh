./configure --build=i686-w64-mingw32 --host=i686-w64-mingw32 --enable-fat  --disable-static --enable-shared ABI=32 CFLAGS="-m32 -march=i686 -Wno-attributes"  --prefix=/local/Win32_DLL --exec-prefix=/local/Win32_DLL 


./configure --build=x86_64-MINGW64  --enable-static --disable-shared ABI=64  CFLAGS="-m64 -march=k8 -Wno-attributes" --with-gmp=/local/Win64  --with-mpfr=/local/Win64  --prefix=/local/Win64 

./configure --build=x86_64-w64-mingw32 --host=x86_64-w64-mingw32 --enable-static --disable-shared  CFLAGS="-m64 -march=k8 -Wno-attributes" --with-gmp-include=/local/Win64/include --with-gmp-lib=/local/Win64/lib  --with-mpfr-include=/local/Win64/include --with-mpfr-lib=/local/Win64/lib  --prefix=/local/Win64 --exec-prefix=/local/Win64  


